import PropTypes from "prop-types";
import { useEffect, useState } from "react";
import useAuth from "./useAuth";

const HasPermission = ({ permission, action, children }) => {
  const { userData } = useAuth();
  const [hasPermissionValue, setHasPermissionValue] = useState(false);

  useEffect(() => {
    const checkPermission = () => {
      if (!userData || !userData.permissions) {
        setHasPermissionValue(false);
        return;
      }

      const categoryPermissions = userData.permissions[permission]?.Actions || [];

      if (!categoryPermissions) {
        setHasPermissionValue(false);
        return;
      }

      if (!action) {
        setHasPermissionValue(categoryPermissions.length > 0);
      } else {
        setHasPermissionValue(categoryPermissions.includes(action));
      }
    };

    checkPermission();
  }, [userData, permission, action]);

  if (hasPermissionValue) {
    return <>{children}</>;
  }

  return false;
};

HasPermission.propTypes = {
  permission: PropTypes.string.isRequired,
  action: PropTypes.string,
  children: PropTypes.node.isRequired,
};

export default HasPermission;