import React, { useEffect, useState } from 'react';
import './AdminOrder.css';
import {baseUrl} from '../../config';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AdminOrder = ({ orderId }) => {
    const [orderDetails, setOrderDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [minPurchase, setMinPurchase] = useState('');
    const [surcharge, setSurcharge] = useState('');
    const [shippingPrice, setShippingPrice] = useState('');

    useEffect(() => {
        fetchConfig();
        fetchOrderDetails();
    }, [orderId]);

    const fetchConfig = () => {
        fetch(`${baseUrl}/config.php`)
            .then(response => response.json())
            .then(config => {
                setMinPurchase(config.min_purchase_amount);
                setSurcharge(config.surcharge_amount);
                setShippingPrice(config.shipping_price); 
            })
            .catch(error => {
                console.error("Error fetching configuration:", error);
            });
    };

    const fetchOrderDetails = () => {
        const mockData = {
            id: orderId,
            date: '2024-10-23',
            total: '150.00',
            status: 'preparing',
            items: [
                { id: 1, name: 'Dog Toy', quantity: 2, price: '10.00', image: 'https://via.placeholder.com/50' },
                { id: 2, name: 'Cat Food', quantity: 1, price: '30.00', image: 'https://via.placeholder.com/50' },
            ],
        };

        setTimeout(() => {
            setOrderDetails(mockData);
            setLoading(false);
        }, 500);
    };

    const handleSaveConfig = () => {
        fetch(`${baseUrl}/config.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                min_purchase_amount: parseFloat(minPurchase),
                surcharge_amount: parseFloat(surcharge),
                shipping_price: parseFloat(shippingPrice)
            }),
        })
            .then(response => response.json())
            .then(result => {
                console.log(result);
                toast.success(result.message);
                if (result.error) {
                    console.error("Error updating configuration:", result.error);
                }
            })
            .catch(error => {
                console.error("Error saving configuration:", error);
            });
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!orderDetails) {
        return <div>Order not found.</div>;
    }

    return (
        <>
    <ToastContainer position="top-right" />
        <div className="order-flow-container">
            <h1>Order #{orderId}</h1>
            <div className="order-summary">
                <p><strong>Date:</strong> {orderDetails.date}</p>
                <p><strong>Total:</strong> ${orderDetails.total}</p>
            </div>

            {/* Existing order details here */}

            <div className="order-config">
                <h2>Order Configuration</h2>
                <div className="config-field">
                    <label htmlFor="minPurchase">Minimum Purchase Amount (Q):</label>
                    <input
                        type="number"
                        id="minPurchase"
                        value={minPurchase}
                        onChange={(e) => setMinPurchase(e.target.value)}
                        placeholder="Enter minimum purchase amount"
                    />
                </div>
                <div className="config-field">
                    <label htmlFor="surcharge">Surcharge Amount (Q):</label>
                    <input
                        type="number"
                        id="surcharge"
                        value={surcharge}
                        onChange={(e) => setSurcharge(e.target.value)}
                        placeholder="Enter surcharge amount"
                    />
                </div>
                <div className="config-field"> 
                    <label htmlFor="shippingPrice">Shipping Price (Q):</label>
                    <input
                        type="number"
                        id="shippingPrice"
                        value={shippingPrice}
                        onChange={(e) => setShippingPrice(e.target.value)}
                        placeholder="Enter shipping price"
                    />
                </div>
                <button className="save-config-button" onClick={handleSaveConfig}>Save Configuration</button>
            </div>
        </div>
        </>
    );
};

export default AdminOrder;
