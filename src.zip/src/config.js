export const baseUrl = " https://6378-181-199-210-226.ngrok-free.app/apis"

//export const baseUrl = "http://localhost/apis"



