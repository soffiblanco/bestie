export const baseUrl = "https://8e34-181-189-154-248.ngrok-free.app/apis"

//export const baseUrl = "http://localhost/apis"



