//export const baseUrl = "https://d188-181-199-210-226.ngrok-free.app/apis"

export const baseUrl = "http://localhost/apis"



